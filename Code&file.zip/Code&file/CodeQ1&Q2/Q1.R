library(gdata)
library(ggplot2)
library(dplyr)
library(tidyr)
library(tidyverse)

keyword<-read.csv("Keyword_data.csv")

key1 <- keyword[-1]

key1 <- key1%>%
  mutate_if(is.factor,as.character)
write.csv(key1, "key.csv", row.names = FALSE)

key <- read.csv("key.csv")
key <- key%>%
  mutate_if(is.factor,as.character)


result <- data.frame()
row_num <-1
for (n in 1:nrow(key)){
  
  for (i in 1:12){
    
      for(j in 1:12){
        if (as.character(key[n,][i])!='' & as.character(key[n,][j])!=''& i != j ){
          
          result[row_num,1] <-as.character(key[n,][i])
          result[row_num,2] <-as.character(key[n,][j])
          row_num <- row_num+1
          
          
        }
        
      }

  }

}

result1 <- result %>% group_by(V1, V2) %>% count() %>% arrange(desc(n))
result2 <- result1 %>% group_by(V1) %>% count() %>% arrange(desc(n))
write.csv(result1, "link.csv", row.names = FALSE)
write.csv(result2, "points.csv", row.names = FALSE)
